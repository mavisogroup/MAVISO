# MAVISO

Next generation delivery platform for Africa.

## Products

- `apps/client` — customer mobile app
- `apps/rider` — delivery rider app
- `apps/business` — merchant app
- `apps/admin` — administration dashboard
- `backend` — APIs and database
- `docs` — product documentation
- `design` — brand references

## Current version

v0.1.0 — Client foundation.

## Run

```bash
cd apps/client
flutter create .
flutter pub get
flutter run
```
