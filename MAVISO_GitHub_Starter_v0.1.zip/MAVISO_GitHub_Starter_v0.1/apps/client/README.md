# MAVISO Client

```bash
flutter create .
flutter pub get
flutter run
```
